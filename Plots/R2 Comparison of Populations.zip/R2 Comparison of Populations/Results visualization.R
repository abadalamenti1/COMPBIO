modtable <- function(z){
  tab <- read.table(z,stringsAsFactors=FALSE)
  tab <- tab[-1,]
  z1 = gsub('^.*?chr','',z)
  chrNum = gsub('.txt','',z1)
  tab <- cbind(tab,as.numeric(chrNum))
}

load_data <- function(expr) { 
  setwd('F:/COMP 383 Final Project/Results/')
  files <- dir('F:/COMP 383 Final Project/Results/',pattern = expr)
  tables <- lapply(files, modtable)
  tables <- do.call(rbind, tables)
  tables <- cbind(tables,expr)
  colnames(tables) = c('gene','alpha', 'cvm', 'lambda.iteration', 'lambda.min', 'n.snps', 'R2',  'pval','ChromosomeNumber','Population')
  tables
}

expplot_ly = c('CHB_p310-fold','GIH_p310-fold','JPT_p310-fold','LWK_p310-fold','MEX_p310-fold','MKK_p310-fold','YRI_p310-fold')

k = lapply(expplot_ly, load_data)
k1 = do.call(rbind,k)
k1$R2 <- as.numeric(k1$R2)
library(dplyr)
#library(plotly)
library(reshape2)
#library(GGally)
#Wide Format
w <- dcast(k1,gene+ChromosomeNumber~Population,value.var = 'R2')
#Long Format
l <- k1
l$n.snps = as.numeric(l$n.snps)
ind = which(l$R2 >= 0.1)
Y <- l[ind,]
YY <- dcast(Y,gene+ChromosomeNumber~Population,value.var = 'R2')

v = w
rownames(v) = v[,1]
X <- v[YY$gene,]

X1 = group_by(l,Population)
X2 = summarise(X1,
               su = sum(n.snps)
               )
X1 = group_by(l, gene)
X3 = summarise(X1,
               su = sum(n.snps)
)
X1 = group_by(l, gene,Population)
X4 = summarise(X1,
               su = sum(n.snps)
)


Y1 = w
Y1$CvJ = Y1$`CHB_p310-fold` - Y1$`JPT_p310-fold`

Y1$CvG = Y1$`CHB_p310-fold` - Y1$`GIH_p310-fold`

Y1$CvL = Y1$`CHB_p310-fold` - Y1$`LWK_p310-fold`

Y1$CvMex = Y1$`CHB_p310-fold` - Y1$`MEX_p310-fold`

Y1$CvMKK = Y1$`CHB_p310-fold`-Y1$`MKK_p310-fold`


Y1$CvY = Y1$`CHB_p310-fold`-  Y1$`YRI_p310-fold`


Y1$GvJ = w$`GIH_p310-fold`-w$`JPT_p310-fold`


Y1$GvL = w$`GIH_p310-fold`-w$`LWK_p310-fold`


Y1$GvMex = w$`GIH_p310-fold` - w$`MEX_p310-fold`

Y1$GvMKK = w$`GIH_p310-fold`-w$`MKK_p310-fold`

Y1$GvY = w$`GIH_p310-fold`- w$`YRI_p310-fold`


Y1$JvL = w$`JPT_p310-fold`-w$`LWK_p310-fold`


Y1$JvMex = w$`JPT_p310-fold`-w$`MEX_p310-fold`


Y1$JvMKK = w$`JPT_p310-fold`-w$`MKK_p310-fold`


Y1$JvY = w$`JPT_p310-fold`-w$`YRI_p310-fold`

Y1$LvMex = w$`LWK_p310-fold` - w$`MEX_p310-fold`


Y1$LvMKK = w$`LWK_p310-fold` - w$`MKK_p310-fold`


Y1$LvY = w$`LWK_p310-fold` - w$`YRI_p310-fold`

Y1$MexvMKK = w$`MEX_p310-fold`-w$`MKK_p310-fold`

Y1$MexvY = w$`MEX_p310-fold`-w$`YRI_p310-fold`

Y1$MKKvY = w$`MKK_p310-fold`-w$`YRI_p310-fold`

#abline(h = .1, col = 'red',lty = 'solid')
#abline(h = -.1, col = 'red',lty = 'solid')
#rownames(Y1) = Y1$gene

#Pulling genes
#This pulls out genes with diff greater than .1
#Y1[abs(Y1$CvJ) > .1,]

#w[is.na(w)] = -1
#plot_ly(x = w$`CHB_p310-fold`,y =w$`GIH_p310-fold`,mode = 'markers',text = c('GENE: ', w$gene))
#pairs(w[,3:9])
#ggscatmat(w,columns = 3:9)
library(plotly)
py <- plotly(username='jng2', key='tp4ag7lilh')

trace1 <- plot_ly(w,
  x = w$`CHB_p310-fold`,
  y = w$`GIH_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)",
    size = 10
  ), 
  mode = "markers", 
  
 
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)

trace2 <- plot_ly(w,
  x = w$`CHB_p310-fold`,
  y = w$`JPT_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  type = "scatter", 
  hoverinfo= "text",
  text = c('Gene: ',w$gene)
)
trace3 <- plot_ly(w,
  x = w$`CHB_p310-fold`,
  y = w$`LWK_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
 
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace3
trace4 <- plot_ly(w,
  x = w$`CHB_p310-fold`,
  y = w$`MEX_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)",
    size = 10
  ), 
  mode = "markers", 
  
 
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)

trace5 <- plot_ly(w,
  x = w$`CHB_p310-fold`,
  y = w$`MKK_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
 
 
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)

trace6 <- plot_ly(w,
  x = w$`CHB_p310-fold`,
  y = w$`YRI_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace7 <- plot_ly(w,
  x = w$`GIH_p310-fold`,
  y = w$`JPT_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace8 <- plot_ly(w,
  x = w$`GIH_p310-fold`,
  y = w$`LWK_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace9 <- plot_ly(w,
  x = w$`GIH_p310-fold`,
  y = w$`MEX_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace9
trace10 <- plot_ly(w,
  x = w$`GIH_p310-fold`,
  y = w$`MKK_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace10
trace11 <- plot_ly(w,
  x = w$`GIH_p310-fold`,
  y = w$`YRI_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace11
trace12 <- plot_ly(w,
  x = w$`JPT_p310-fold`,
  y = w$`LWK_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace12
trace13 <- plot_ly(w,
  x = w$`JPT_p310-fold`,
  y = w$`MEX_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace13
trace14 <- plot_ly(w,
  x = w$`JPT_p310-fold`,
  y = w$`MKK_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace14
trace15 <- plot_ly(w,
  x = w$`JPT_p310-fold`,
  y = w$`YRI_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace15
trace16 <- plot_ly(w,
  x = w$`LWK_p310-fold`,
  y = w$`MEX_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace16
trace17 <- plot_ly(w,
  x = w$`LWK_p310-fold`,
  y = w$`MKK_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace17
trace18 <- plot_ly(w,
  x = w$`LWK_p310-fold`,
  y = w$`YRI_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace18
trace19 <- plot_ly(w,
  x = w$`MEX_p310-fold`,
  y = w$`MKK_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace19
trace20 <- plot_ly(w,
  x = w$`MEX_p310-fold`,
  y = w$`YRI_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
  
  
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace20
trace21 <- plot_ly(w,
  x = w$`MKK_p310-fold`,
  y = w$`YRI_p310-fold`,
  marker = list(
    color = "rgb(255,0,28)", 
    size = 10
  ), 
  mode = "markers", 
                   
                   
  type = "scatter", 
  hoverinfo = "text",
  text = c('Gene: ',w$gene)
)
trace21
# data <- plot_ly(trace1, trace2, trace3, trace4, trace5, trace6, trace7, trace8, trace9, trace10, trace11, trace12, trace13, trace14, trace15, trace16, trace17, trace18, trace19, trace20)
# layout <- plot_ly(
#   height = 850, 
#   showlegend = FALSE, 
#   title = "Scatterplot Matrix", 
#   width = 850, 
#   xaxis = plot_ly(
#     domain = c(0.0, 1), 
#     showline = FALSE, 
#     title = "pH", 
#     zeroline = FALSE
#   ), 
#   xaxis2 = plot_ly(
#     domain = c(0, 1), 
#     showline = FALSE, 
#     title = "chlorides", 
#     zeroline = FALSE
#   ), 
#   xaxis3 = plot_ly(
#     domain = c(0, 1), 
#     showline = FALSE, 
#     title = "sulphates", 
#     zeroline = FALSE
#   ), 
#   xaxis4 = plot_ly(
#     domain = c(0, 1), 
#     showline = FALSE, 
#     title = "alcohol", 
#     zeroline = FALSE
#   ), 
#   xaxis5 = plot_ly(
#     domain = c(0, 1), 
#     position = 0.235, 
#     showticklabels = FALSE, 
#     side = "top"
#   
#   ), 
#   yaxis = plot_ly(
#     domain = c(0, 1), 
#     position = 1, 
#     showline = FALSE, 
#     side = "right", 
#     title = "pH", 
#     zeroline = FALSE
#   ), 
#   yaxis2 = plot_ly(
#     domain = c(0, 1), 
#     position = 1, 
#     showline = FALSE, 
#     side = "right", 
#     title = "chlorides", 
#     zeroline = FALSE
#   ), 
#   yaxis3 = plot_ly(
#     domain = c(0, 1), 
#     position = 1, 
#     showline = FALSE, 
#     side = "right", 
#     title = "sulphates", 
#     zeroline = FALSE
#   ),
#   yaxis4 = plot_ly(
#     domain = c(0, 1),
#     position = 1, 
#     showline = FALSE, 
#     side = "right", 
#     title = "sulphates", 
#     zeroline = FALSE
#   )
# )
# response <- py$plotly(data, kwargs=plot_ly(layout=layout))
# url <- response$url


